import { addons } from '@storybook/addons';
import yourTheme from './MonTheme';

addons.setConfig({
    theme: yourTheme,
});